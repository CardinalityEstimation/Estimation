package sinc2.rule;

/**
 * The five cases of specialization operations
 *
 * @since 2.0
 */
public enum SpecOprCase {
    CASE1, CASE2, CASE3, CASE4, CASE5
}
