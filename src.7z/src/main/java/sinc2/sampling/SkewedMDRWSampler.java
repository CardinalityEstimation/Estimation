package sinc2.sampling;

import sinc2.kb.SimpleKb;

public class SkewedMDRWSampler extends Sampler {
    @Override
    public SamplingInfo sample(SimpleKb originalKb, int budget, String sampledKbName) {
        // Todo: Implement here
        throw new Error("Not Implemented");
    }
}
