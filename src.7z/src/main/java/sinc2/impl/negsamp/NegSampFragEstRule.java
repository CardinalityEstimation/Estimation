package sinc2.impl.negsamp;

import sinc2.common.ArgLocation;
import sinc2.common.Argument;
import sinc2.common.Predicate;
import sinc2.common.Record;
import sinc2.impl.est.FragmentedEstRule;
import sinc2.impl.est.SpecOprWithScore;
import sinc2.impl.est.VarLink;
import sinc2.impl.est.VarPair;
import sinc2.kb.IntTable;
import sinc2.kb.SimpleKb;
import sinc2.kb.SimpleRelation;
import sinc2.rule.*;
import sinc2.util.ArrayOperation;
import sinc2.util.MultiSet;

import java.util.*;

public class NegSampFragEstRule extends FragmentedEstRule {

    /** This cache is used to monitor sampled negative records (N-cache). One cache fragment is sufficient as all
     *  predicates are linked to the head. */
    protected CacheFragment negCache;
    /** The map from negative examples to their weight. If NULL, all negative examples are weighted as 1. */
    final protected Map<Record, Float> negSampleWeightMap;

    /* Monitoring info. The time (in nanoseconds) refers to the corresponding time consumption in the last update of the rule */
    protected long negCacheUpdateTime = 0;
    protected long negCacheIndexingTime = 0;

    public NegSampFragEstRule(
            int headPredSymbol, int arity, Set<Fingerprint> fingerprintCache,
            Map<MultiSet<Integer>, Set<Fingerprint>> category2TabuSetMap, SimpleKb kb,
            Map<Record, Float> negSampleWeightMap, IntTable negSamples
    ) {
        super(headPredSymbol, arity, fingerprintCache, category2TabuSetMap, kb);
        negCache = new CacheFragment(negSamples, headPredSymbol);
        this.negSampleWeightMap = negSampleWeightMap;
        /* Evaluation has already been calculated in super() */
    }

    public NegSampFragEstRule(NegSampFragEstRule another) {
        super(another);
        this.negCache = new CacheFragment(another.negCache);
        this.negSampleWeightMap = another.negSampleWeightMap;
    }

    @Override
    public NegSampFragEstRule clone() {
        long time_start = System.nanoTime();
        NegSampFragEstRule rule =  new NegSampFragEstRule(this);
        rule.copyTime = System.nanoTime() - time_start;
        return rule;
    }

    /**
     * Calculate the evaluation of the rule.
     */
    @Override
    protected Eval calculateEval() {
        int new_pos_ent = posCache.countTableSize(HEAD_PRED_IDX);
        float neg_ent;
        if (null == negSampleWeightMap) {
            /* Equal weight. Only count the number of negative samples */
            neg_ent = negCache.countTableSize(HEAD_PRED_IDX);
        } else {
            /* Count the total weight of negative entailments */
            Set<int[]> neg_ent_set = new HashSet<>();   // object reference is sufficient for identifying a record in a (neg-) KB
            neg_ent = 0;
            for (List<CB> cache_entry: negCache.entries) {
                for (int[] neg_record: cache_entry.get(HEAD_PRED_IDX).complianceSet) {
                    if (neg_ent_set.add(neg_record)) {
                        neg_ent += negSampleWeightMap.get(new Record(neg_record));
                    }
                }
            }
        }
        return new Eval(new_pos_ent, new_pos_ent + neg_ent, length);
    }

    /**
     * This method calculates real evaluation based on the accurate number of positive and negative entailments and
     * replaces the rule evaluation with it.
     */
    public void calcRealEval() {
        eval = super.calculateEval();
    }

    @Override
    public void updateCacheIndices() {
        long time_start = System.nanoTime();
        posCache.buildIndices();
        long time_pos_done = System.nanoTime();
        entCache.buildIndices();
        long time_ent_done = System.nanoTime();
        for (CacheFragment fragment: allCache) {
            fragment.buildIndices();
        }
        long time_all_done = System.nanoTime();
        negCache.buildIndices();
        long time_neg_done = System.nanoTime();
        posCacheIndexingTime = time_pos_done - time_start;
        entCacheIndexingTime = time_ent_done - time_pos_done;
        allCacheIndexingTime = time_all_done - time_ent_done;
        negCacheIndexingTime = time_neg_done - time_all_done;
    }

    @Override
    protected UpdateStatus cvt1Uv2ExtLvHandlerPostCvg(int predIdx, int argIdx, int varId) {
        long time_start = System.nanoTime();
        negCache.updateCase1a(predIdx, argIdx, varId);
        negCacheUpdateTime = System.nanoTime() - time_start;
        return super.cvt1Uv2ExtLvHandlerPostCvg(predIdx, argIdx, varId);
    }

    @Override
    protected UpdateStatus cvt1Uv2ExtLvHandlerPostCvg(Predicate newPredicate, int argIdx, int varId) {
        long time_start = System.nanoTime();
        SimpleRelation new_relation = kb.getRelation(newPredicate.predSymbol);
        negCache.updateCase1b(new_relation, new_relation.id, argIdx, varId);
        negCacheUpdateTime = System.nanoTime() - time_start;
        return super.cvt1Uv2ExtLvHandlerPostCvg(newPredicate, argIdx, varId);
    }

    @Override
    protected UpdateStatus cvt2Uvs2NewLvHandlerPostCvg(int predIdx1, int argIdx1, int predIdx2, int argIdx2) {
        long time_start = System.nanoTime();
        negCache.updateCase2a(predIdx1, argIdx1, predIdx2, argIdx2, usedLimitedVars() - 1);
        negCacheUpdateTime = System.nanoTime() - time_start;
        return super.cvt2Uvs2NewLvHandlerPostCvg(predIdx1, argIdx1, predIdx2, argIdx2);
    }

    @Override
    protected UpdateStatus cvt2Uvs2NewLvHandlerPostCvg(Predicate newPredicate, int argIdx1, int predIdx2, int argIdx2) {
        long time_start = System.nanoTime();
        SimpleRelation new_relation = kb.getRelation(newPredicate.predSymbol);
        negCache.updateCase2b(new_relation, new_relation.id, argIdx1, predIdx2, argIdx2, usedLimitedVars() - 1);
        negCacheUpdateTime = System.nanoTime() - time_start;
        return super.cvt2Uvs2NewLvHandlerPostCvg(newPredicate, argIdx1, predIdx2, argIdx2);
    }

    @Override
    protected UpdateStatus cvt1Uv2ConstHandlerPostCvg(int predIdx, int argIdx, int constant) {
        long time_start = System.nanoTime();
        negCache.updateCase3(predIdx, argIdx, constant);
        negCacheUpdateTime = System.nanoTime() - time_start;
        return super.cvt1Uv2ConstHandlerPostCvg(predIdx, argIdx, constant);
    }

    @Override
    public void releaseMemory() {
        super.releaseMemory();
        negCache = null;
    }

//    public List<SpecOprWithScore> estimateSpecializations() {
//        /* Gather values in columns */
//        List<MultiSet<Integer>[]> column_values_in_pos_cache = new ArrayList<>();
//        List<MultiSet<Integer>[]> column_values_in_neg_cache = new ArrayList<>();
//        boolean[][] vars_in_preds = new boolean[structure.size()][];
//        for (int pred_idx = HEAD_PRED_IDX; pred_idx < structure.size(); pred_idx++) {
//            Predicate predicate = structure.get(pred_idx);
//            MultiSet<Integer>[] arg_sets_pos = new MultiSet[predicate.arity()];
//            MultiSet<Integer>[] arg_sets_ent = new MultiSet[predicate.arity()];
//            MultiSet<Integer>[] arg_sets_all = new MultiSet[predicate.arity()];
//            for (int i = 0; i < arg_sets_pos.length; i++) {
//                arg_sets_pos[i] = new MultiSet<>();
//                arg_sets_ent[i] = new MultiSet<>();
//                arg_sets_all[i] = new MultiSet<>();
//            }
//            column_values_in_pos_cache.add(arg_sets_pos);
//            column_values_in_neg_cache.add(arg_sets_ent);
//            boolean[] vars_in_pred = new boolean[usedLimitedVars()];
//            for (int arg: predicate.args) {
//                if (Argument.isVariable(arg)) {
//                    vars_in_pred[Argument.decode(arg)] = true;
//                }
//            }
//            vars_in_preds[pred_idx] = vars_in_pred;
//        }
//        for (List<CB> cache_entry: posCache) {
//            for (int pred_idx = HEAD_PRED_IDX; pred_idx < structure.size(); pred_idx++) {
//                CB cb = cache_entry.get(pred_idx);
//                MultiSet<Integer>[] arg_sets = column_values_in_pos_cache.get(pred_idx);
//                for (int arg_idx = 0; arg_idx < cb.complianceSet[0].length; arg_idx++) {
//                    MultiSet<Integer> arg_set = arg_sets[arg_idx];
//                    for (int[] record: cb.complianceSet) {
//                        arg_set.add(record[arg_idx]);
//                    }
//                }
//            }
//        }
//        for (List<CB> cache_entry: negCache) {
//            for (int pred_idx = HEAD_PRED_IDX; pred_idx < structure.size(); pred_idx++) {
//                CB cb = cache_entry.get(pred_idx);
//                MultiSet<Integer>[] arg_sets = column_values_in_neg_cache.get(pred_idx);
//                for (int arg_idx = 0; arg_idx < cb.complianceSet[0].length; arg_idx++) {
//                    MultiSet<Integer> arg_set = arg_sets[arg_idx];
//                    for (int[] record: cb.complianceSet) {
//                        arg_set.add(record[arg_idx]);
//                    }
//                }
//            }
//        }
//
//        /* Find all empty arguments */
//        List<ArgLocation> empty_args = new ArrayList<>();
//        for (int pred_idx = Rule.HEAD_PRED_IDX; pred_idx < structure.size(); pred_idx++) {
//            final Predicate predicate = structure.get(pred_idx);
//            for (int arg_idx = 0; arg_idx < predicate.arity(); arg_idx++) {
//                if (Argument.isEmpty(predicate.args[arg_idx])) {
//                    empty_args.add(new ArgLocation(pred_idx, arg_idx));
//                }
//            }
//        }
//
//        /* Estimate case 1 & 2 */
//        List<SpecOprWithScore> results = new ArrayList<>();
//        for (int var_id = 0; var_id < usedLimitedVars(); var_id++) {
//            List<ArgLocation> var_arg_locs = limitedVarArgs.get(var_id);
//            final int var_arg = Argument.variable(var_id);
//
//            /* Case 1 */
//            for (ArgLocation vacant: empty_args) {
//                int another_arg_idx = -1;   // another arg in the same predicate with 'vacant' that shares the same var
//                {
//                    Predicate vacant_pred = structure.get(vacant.predIdx);
//                    for (int arg_idx = 0; arg_idx < vacant_pred.arity(); arg_idx++) {
//                        if (var_arg == vacant_pred.args[arg_idx]) {
//                            another_arg_idx = arg_idx;
//                            break;
//                        }
//                    }
//                }
//
//                double est_pos_ent, est_neg_ent;
//                if (-1 != another_arg_idx) {
//                    /* There is another occurrence of var in the same predicate */
//                    // Todo: Random sampling may be applied here
//                    int remaining_rows = 0;
//                    for (List<CB> cache_entry: posCache) {
//                        CB cb = cache_entry.get(vacant.predIdx);
//                        for (int[] record: cb.complianceSet) {
//                            remaining_rows += record[another_arg_idx] == record[vacant.argIdx] ? 1 : 0;
//                        }
//                    }
//                    est_pos_ent = eval.getPosEtls() / column_values_in_pos_cache.get(vacant.predIdx)[vacant.argIdx].size() * remaining_rows;
//
//                    // Todo: Random sampling may be applied here
//                    if (negCache.isEmpty()) {
//                        est_neg_ent = 0;
//                    } else {
//                        remaining_rows = 0;
//                        for (List<CB> cache_entry : negCache) {
//                            CB cb = cache_entry.get(vacant.predIdx);
//                            for (int[] record : cb.complianceSet) {
//                                remaining_rows += record[another_arg_idx] == record[vacant.argIdx] ? 1 : 0;
//                            }
//                        }
//                        est_neg_ent = entailed_record_cnt / column_values_in_neg_cache.get(vacant.predIdx)[vacant.argIdx].size() * remaining_rows;
//                    }
//
//                    if (HEAD_PRED_IDX == vacant.predIdx) {
//                        est_all_ent = eval.getAllEtls() / kb.totalConstants();
//                    } else {
//                        // Todo: Random sampling may be applied here
//                        remaining_rows = 0;
//                        TabInfo tab_info = predIdx2AllCacheTableInfo.get(vacant.predIdx);
//                        for (List<CB> cache_entry: allCache.get(tab_info.fragmentIdx)) {
//                            CB cb = cache_entry.get(tab_info.tabIdx);
//                            for (int[] record: cb.complianceSet) {
//                                remaining_rows += record[another_arg_idx] == record[vacant.argIdx] ? 1 : 0;
//                            }
//                        }
//                        est_all_ent = eval.getAllEtls() / column_values_in_all_cache.get(vacant.predIdx)[vacant.argIdx].size() * remaining_rows;
//                    }
//                } else {
//                    /* Other occurrences of the var are in different predicates */
//                    double[] est_pos_ratios = new double[var_arg_locs.size() + 1];
//                    {
//                        MultiSet<Integer> vacant_column_values_pos = column_values_in_pos_cache.get(vacant.predIdx)[vacant.argIdx];
//                        for (int i = 0; i < var_arg_locs.size(); i++) {
//                            ArgLocation var_arg_loc = var_arg_locs.get(i);
//                            MultiSet<Integer> var_column_values_pos = column_values_in_pos_cache.get(var_arg_loc.predIdx)[var_arg_loc.argIdx];
//                            est_pos_ratios[i] = ((double) var_column_values_pos.itemCount(vacant_column_values_pos.distinctValues())) / var_column_values_pos.size();
//                        }
//                        ArgLocation _arg_loc_of_var = var_arg_locs.get(0);
//                        est_pos_ratios[est_pos_ratios.length - 1] = ((double) vacant_column_values_pos.itemCount(
//                                column_values_in_pos_cache.get(_arg_loc_of_var.predIdx)[_arg_loc_of_var.argIdx].distinctValues()
//                        )) / vacant_column_values_pos.size();
//                    }
//                    est_pos_ent = estimateRatiosInPosCache(est_pos_ratios) * eval.getPosEtls();
//
//                    if (0 == entailed_record_cnt) {
//                        est_already_ent = 0;
//                    } else {
//                        double[] est_ent_ratios = new double[var_arg_locs.size() + 1];
//                        MultiSet<Integer> vacant_column_values_ent = column_values_in_ent_cache.get(vacant.predIdx)[vacant.argIdx];
//                        for (int i = 0; i < var_arg_locs.size(); i++) {
//                            ArgLocation var_arg_loc = var_arg_locs.get(i);
//                            MultiSet<Integer> var_column_values_ent = column_values_in_ent_cache.get(var_arg_loc.predIdx)[var_arg_loc.argIdx];
//                            est_ent_ratios[i] = ((double) var_column_values_ent.itemCount(vacant_column_values_ent.distinctValues())) / var_column_values_ent.size();
//                        }
//                        ArgLocation _arg_loc_of_var = var_arg_locs.get(0);
//                        est_ent_ratios[est_ent_ratios.length - 1] = ((double) vacant_column_values_ent.itemCount(
//                                column_values_in_ent_cache.get(_arg_loc_of_var.predIdx)[_arg_loc_of_var.argIdx].distinctValues()
//                        )) / vacant_column_values_ent.size();
//                        est_already_ent = estimateRatiosInPosCache(est_ent_ratios) * entailed_record_cnt;
//                    }
//
//                    boolean[] vars_in_head = vars_in_preds[HEAD_PRED_IDX];
//                    if (HEAD_PRED_IDX == vacant.predIdx) {
//                        /* Find a linked var with this one both in head and body (with the shortest path) */
//                        VarLink[] var_link_path = null;
//                        for (int head_vid = 0; head_vid < vars_in_head.length; head_vid++) {
//                            if (vars_in_head[head_vid]) {
//                                VarLink[] _var_link_path = bodyVarLinkManager.shortestPath(head_vid, var_id);
//                                if (null != _var_link_path && (null == var_link_path || _var_link_path.length < var_link_path.length)) {
//                                    var_link_path = _var_link_path;
//                                }
//                            }
//                        }
//                        /* Theoretically, var_link_path != null */
//                        /* The new var is body-linked with some vars in the head, estimate according to the shortest path */
//                        est_all_ent = eval.getAllEtls() / kb.totalConstants() * estimateLinkVarRatio(var_link_path, column_values_in_all_cache);
////                        if (null == var_link_path) {
////                            /* The new var is not body-linked with any of the vars in the head */
////                            ArgLocation arg_loc_of_var = args_of_var.get(0);
////                            est_all_ent = ((double) column_values_in_all_cache.get(arg_loc_of_var.predIdx)[arg_loc_of_var.argIdx].differentValues())
////                                    / kb.totalConstants() * eval.getAllEtls();
////                        }
//                    } else {
//                        Set<VarPair> new_linked_var_pairs = bodyVarLinkManager.assumeSpecOprCase1(vacant.predIdx, vacant.argIdx, var_id);
//                        est_all_ent = eval.getAllEtls();
//                        for (VarPair new_linked_var_pair: new_linked_var_pairs) {
//                            if (vars_in_head[new_linked_var_pair.vid1] && vars_in_head[new_linked_var_pair.vid2]) {
//                                for (ArgLocation arg_loc_of_v2: limitedVarArgs.get(new_linked_var_pair.vid2)) {
//                                    if (HEAD_PRED_IDX != arg_loc_of_v2.predIdx) {
//                                        /* Find an occurrence of vid2 in the body to get the number of values assigned to that var */
//                                        VarLink[] var_link_path = bodyVarLinkManager.assumeShortestPathCase1(
//                                                vacant.predIdx, vacant.argIdx, var_id, new_linked_var_pair.vid1, new_linked_var_pair.vid2
//                                        );
//                                        est_all_ent = est_all_ent / column_values_in_all_cache.get(arg_loc_of_v2.predIdx)[arg_loc_of_v2.argIdx].differentValues()
//                                                * estimateLinkVarRatio(var_link_path, column_values_in_all_cache);
//                                        break;
//                                    }
//                                }
//                                break;
//                            }
//                        }
//                        /* Find other occurrences of this var in the body */
//                        List<ArgLocation> var_arg_locs_in_body = new ArrayList<>();
//                        for (ArgLocation arg_loc: var_arg_locs) {
//                            if (HEAD_PRED_IDX != arg_loc.predIdx) {
//                                var_arg_locs_in_body.add(arg_loc);
//                            }
//                        }
//                        MultiSet<Integer> vacant_column_values = column_values_in_all_cache.get(vacant.predIdx)[vacant.argIdx];
//                        if (!var_arg_locs_in_body.isEmpty()) {
//                            double[] est_all_ratios = new double[var_arg_locs_in_body.size() + 1];
//                            for (int i = 0; i < var_arg_locs_in_body.size(); i++) {
//                                ArgLocation arg_loc_of_var = var_arg_locs_in_body.get(i);
//                                MultiSet<Integer> var_column_values = column_values_in_all_cache.get(arg_loc_of_var.predIdx)[arg_loc_of_var.argIdx];
//                                est_all_ratios[i] = ((double) var_column_values.itemCount(vacant_column_values.distinctValues())) / var_column_values.size();
//                            }
//                            ArgLocation _arg_loc_of_var = var_arg_locs_in_body.get(0);
//                            est_all_ratios[est_all_ratios.length - 1] = ((double) vacant_column_values.itemCount(
//                                    column_values_in_all_cache.get(_arg_loc_of_var.predIdx)[_arg_loc_of_var.argIdx].distinctValues()
//                            )) / vacant_column_values.size();
//                            est_all_ent *= estimateRatiosInAllCache(est_all_ratios);
//                        }   // Else: the newly added LV must be included in some newly linked pairs and handled by the previous loop
//                    }
//                }
//                results.add(new SpecOprWithScore(
//                        new SpecOprCase1(vacant.predIdx, vacant.argIdx, var_id),
//                        new Eval(est_pos_ent, est_all_ent - est_already_ent, length + 1)
//                ));
//            }
//
//            /* Case 2 */
//            List<ArgLocation> var_arg_locs_in_body = new ArrayList<>();
//            for (ArgLocation arg_loc: var_arg_locs) {
//                if (HEAD_PRED_IDX != arg_loc.predIdx) {
//                    var_arg_locs_in_body.add(arg_loc);
//                }
//            }
//            for (SimpleRelation relation: kb.getRelations()) {
//                for (int arg_idx = 0; arg_idx < relation.totalCols(); arg_idx++) {
//                    double[] est_pos_ratios = new double[var_arg_locs.size()];
//                    Collection<Integer> relation_column_values = ArrayOperation.toCollection(relation.valuesInColumn(arg_idx));
//                    for (int i = 0; i < est_pos_ratios.length; i++) {
//                        ArgLocation arg_loc_of_var = var_arg_locs.get(i);
//                        MultiSet<Integer> var_column_values_pos = column_values_in_pos_cache.get(arg_loc_of_var.predIdx)[arg_loc_of_var.argIdx];
//                        est_pos_ratios[i] = ((double) var_column_values_pos.itemCount(relation_column_values)) / var_column_values_pos.size();
//                    }
//                    double est_pos_ent = estimateRatiosInPosCache(est_pos_ratios) * eval.getPosEtls();
//
//                    double est_already_ent;
//                    if (0 == entailed_record_cnt) {
//                        est_already_ent = 0;
//                    } else {
//                        double[] est_ent_ratios = new double[var_arg_locs.size()];
//                        for (int i = 0; i < est_pos_ratios.length; i++) {
//                            ArgLocation arg_loc_of_var = var_arg_locs.get(i);
//                            MultiSet<Integer> var_column_values_ent = column_values_in_ent_cache.get(arg_loc_of_var.predIdx)[arg_loc_of_var.argIdx];
//                            est_ent_ratios[i] = ((double) var_column_values_ent.itemCount(relation_column_values)) / var_column_values_ent.size();
//                        }
//                        est_already_ent = estimateRatiosInPosCache(est_ent_ratios) * entailed_record_cnt;
//                    }
//
//                    double est_all_ent;
//                    if (var_arg_locs_in_body.isEmpty()) {
//                        /* All occurrences of the var are in the head */
//                        est_all_ent = eval.getAllEtls() / kb.totalConstants() * relation.valuesInColumn(arg_idx).length;
//                    } else {
//                        double[] est_all_ratios = new double[var_arg_locs_in_body.size()];
//                        for (int i = 0; i < est_all_ratios.length; i++) {
//                            ArgLocation arg_loc_of_var = var_arg_locs_in_body.get(i);
//                            MultiSet<Integer> var_column_values = column_values_in_all_cache.get(arg_loc_of_var.predIdx)[arg_loc_of_var.argIdx];
//                            est_all_ratios[i] = ((double) var_column_values.itemCount(relation_column_values)) / var_column_values.size();
//                        }
//                        est_all_ent = estimateRatiosInAllCache(est_all_ratios) * eval.getAllEtls();
//                    }
//                    results.add(new SpecOprWithScore(
//                            new SpecOprCase2(relation.id, relation.totalCols(), arg_idx, var_id),
//                            new Eval(est_pos_ent, est_all_ent - est_already_ent, length + 1)
//                    ));
//                }
//            }
//        }
//
//        ?
//    }
}
