package sinc.common;

public class Variable extends Argument {
    public Variable(int id) {
        super(id, "X" + id, true);
    }
}
