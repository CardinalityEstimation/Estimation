package sinc2.impl.negsamp;

import static org.junit.jupiter.api.Assertions.*;

class RelConstIteratorTest {

}