#include <iostream>
#include "src/impl/app.h"

int main(int argc, char** argv){
    sinc::Main::sincMain(argc, argv);
}
